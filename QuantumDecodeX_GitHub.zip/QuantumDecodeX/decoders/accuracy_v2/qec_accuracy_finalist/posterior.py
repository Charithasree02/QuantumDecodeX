"""Our bounded, deduplicated physical-list posterior experiments.

Only ideas, not implementations, are taken from decoder literature. All helpers
under base/ are this project's frozen earlier kernels plus the licensed organizer
DEM extractor. Inference never receives labels, IDs or saved predictions.
"""
import math
import numpy as np
from numba import njit,prange
from .base.search_fast import reliability_basis,solve_mask,has_bit,candidate_cost
from .base.fast_physics import packed_events,packed_columns,popcount
from .base.model import SparseModel
from .base.harness import inspect_dem,circuit_fingerprint,validate_events

@njit(cache=False)
def bp_proposal(s,sl,sh,ptr,variables,prior,logical,low,high,limit,damping,scale,clip,schedule):
    """0 flooding min-sum, 1 layered min-sum, 2 flooding sum-product.

    3 uses alternating forward/reverse layered checks to perturb trapping sets.
    First parity success stops, exactly as in the retained reference for code 0.
    """
    m=len(prior);r=np.zeros(len(variables),np.float64);q=prior[variables].copy()
    posterior=prior.copy();best=np.zeros(m,np.uint8);hard=best.copy()
    best_res=popcount(sl)+popcount(sh);best_cost=0.;used=0;stable=0
    if best_res==0:return best,posterior,True,used,best_res
    solved=False
    for iteration in range(limit):
        if schedule==0 or schedule==2:posterior[:]=prior
        maxchange=0.
        for ci in range(len(ptr)-1):
            c=(len(ptr)-2-ci) if schedule==3 and iteration%2 else ci
            start,end=ptr[c],ptr[c+1];sign=-1. if s[c] else 1.
            minimum=math.inf;second=math.inf;argmin=-1;logprod=0.;zeros=0
            for e in range(start,end):
                if schedule==1 or schedule==3:q[e]=max(-clip,min(clip,posterior[variables[e]]-r[e]))
                v=q[e]
                if v<0:sign=-sign
                a=abs(v)
                if a<minimum:second=minimum;minimum=a;argmin=e
                elif a<second:second=a
                if schedule==2:
                    t=math.tanh(a*.5)
                    if t==0:zeros+=1
                    else:logprod+=math.log(t)
            for e in range(start,end):
                edge_sign=-sign if q[e]<0 else sign
                if schedule==2:
                    t=math.tanh(abs(q[e])*.5)
                    if zeros-(1 if t==0 else 0)>0:magnitude=0.
                    else:
                        remaining=logprod-(math.log(t) if t else 0.)
                        product=min(1.-1e-13,math.exp(min(0.,remaining)))
                        magnitude=min(clip,math.log1p(product)-math.log1p(-product))
                else:magnitude=min(clip,scale*(second if e==argmin else minimum))
                new=damping*r[e]+(1.-damping)*edge_sign*magnitude
                maxchange=max(maxchange,abs(new-r[e]))
                if schedule==1 or schedule==3:posterior[variables[e]]+=new-r[e]
                else:posterior[variables[e]]+=new
                r[e]=new
        ol=np.uint64(0);oh=np.uint64(0);cost=0.
        for j in range(m):
            hard[j]=np.uint8(posterior[j]<0)
            if hard[j]:ol^=low[j];oh^=high[j];cost+=prior[j]
        residual=popcount(ol^sl)+popcount(oh^sh);used=iteration+1
        if residual<best_res or (residual==best_res and cost<best_cost):best_res=residual;best_cost=cost;best[:]=hard
        if residual==0:solved=True;break
        stable=stable+1 if maxchange<1e-7 else 0
        if stable>=3:break
        if schedule==0 or schedule==2:
            for e in range(len(variables)):q[e]=max(-clip,min(clip,posterior[variables[e]]-r[e]))
    return best,posterior,solved,used,best_res

@njit(cache=False)
def local_columns(sl,sh,low,high,reliability,budget):
    """Bounded reliability-first connectivity growth; no external LSD code.

    A new physical variable must touch the current detector region. Adding it
    grows that region. The local solver later checks membership in its span;
    it does not require full global rank, and safely rejects unsolved regions.
    """
    allowed=np.zeros(len(low),np.bool_);rl=sl;rh=sh;count=0
    ordering=np.argsort(np.abs(reliability),kind='mergesort')
    for sweep in range(3):
        for v in ordering:
            if not allowed[v] and ((low[v]&rl)!=0 or (high[v]&rh)!=0):
                allowed[v]=True;rl|=low[v];rh|=high[v];count+=1
                if count==budget:return allowed,count,popcount(rl)+popcount(rh)
    return allowed,count,popcount(rl)+popcount(rh)

@njit(cache=False)
def insert_unique(bits,cost,mask,stored,costs,masks,slots,count):
    """Hash indexes exact packed-vector equality; collisions never imply equality."""
    digest=np.uint64(1469598103934665603)
    for word in bits:digest=(digest^word)*np.uint64(1099511628211)
    slot=np.int64(digest & np.uint64(len(slots)-1))
    while slots[slot]>=0:
        ix=slots[slot];equal=True
        for k in range(len(bits)):
            if bits[k]!=stored[ix,k]:equal=False;break
        if equal:return count,False
        slot=(slot+1)&(len(slots)-1)
    slots[slot]=count;stored[count,:]=bits;costs[count]=cost;masks[count]=mask
    return count+1,True

@njit(cache=False)
def add_list(s,sl,sh,estimate,reliability,low,high,logical,prior,width,order_limit,local_budget,
             stored,costs,masks,slots,count):
    return add_ranked_list(s,sl,sh,estimate,reliability,low,high,logical,prior,width,order_limit,local_budget,0,stored,costs,masks,slots,count)

@njit(cache=False)
def add_ranked_list(s,sl,sh,estimate,reliability,low,high,logical,prior,width,order_limit,local_budget,generator_mode,
             stored,costs,masks,slots,count):
    checks=len(s);allowed=np.ones(len(low),np.bool_);lv=0;lc=0
    if local_budget>0:
        allowed,lv,lc=local_columns(sl,sh,low,high,reliability,local_budget)
        local_low=low.copy();local_high=high.copy()
        for j in range(len(low)):
            if not allowed[j]:local_low[j]=0;local_high[j]=0
        bl,bh,cl,ch,pivots,selected,ordering,rank=reliability_basis(local_low,local_high,reliability,checks)
        base=np.zeros(len(estimate),np.uint8)
    else:
        bl,bh,cl,ch,pivots,selected,ordering,rank=reliability_basis(low,high,reliability,checks)
        base=estimate.copy()
    dl=sl;dh=sh
    for v in range(len(base)):
        if base[v]:dl^=low[v];dh^=high[v]
    xl,xh,success=solve_mask(dl,dh,bl,bh,cl,ch)
    if not success:return count,0,False,lv,lc
    for j in range(rank):
        if has_bit(xl,xh,j):base[pivots[j]]^=1
    cost=0.;mask=np.uint8(0);ol=np.uint64(0);oh=np.uint64(0)
    bits=np.zeros(stored.shape[1],np.uint64)
    for v in range(len(base)):
        if base[v]:
            cost+=prior[v];mask^=logical[v];ol^=low[v];oh^=high[v]
            bits[v//64]^=np.uint64(1)<<np.uint64(v%64)
    if ol!=sl or oh!=sh:return count,0,False,lv,lc
    count,_=insert_unique(bits,cost,mask,stored,costs,masks,slots,count);generated=1
    alternatives=np.empty(width,np.int64);al=np.empty(width,np.uint64);ah=al.copy();number=0
    if generator_mode>0:
        # Evaluate each generator under original physical priors, then bound
        # combinations. This changes which alternatives are explored, not the
        # candidate budget. Mode 2 reserves one best generator per logical delta.
        gcost=np.full(len(low),math.inf);gl=np.zeros(len(low),np.uint64);gh=gl.copy();delta=np.zeros(len(low),np.uint8)
        for v in range(len(low)):
            if allowed[v] and not selected[v]:
                a,b,ok=solve_mask(low[v],high[v],bl,bh,cl,ch)
                if ok:
                    value,lmask=candidate_cost(base,prior,pivots[:rank],a,b,v,-1,cost,mask,logical)
                    gcost[v]=value;gl[v]=a;gh[v]=b;delta[v]=lmask^mask
        ordering=np.argsort(gcost,kind='mergesort');reserved=np.zeros(len(low),np.bool_)
        if generator_mode==2:
            seen=np.zeros(16,np.bool_)
            for v in ordering:
                if math.isfinite(gcost[v]) and not seen[delta[v]]:
                    alternatives[number]=v;al[number]=gl[v];ah[number]=gh[v];reserved[v]=True;seen[delta[v]]=True;number+=1
                    if number==width:break
        for v in ordering:
            if number==width:break
            if math.isfinite(gcost[v]) and not reserved[v]:
                alternatives[number]=v;al[number]=gl[v];ah[number]=gh[v];number+=1
    if order_limit>0:
        for v in ordering if generator_mode==0 else np.empty(0,np.int64):
            if allowed[v] and not selected[v]:
                a,b,ok=solve_mask(low[v],high[v],bl,bh,cl,ch)
                if ok:
                    alternatives[number]=v;al[number]=a;ah[number]=b;number+=1
                    if number==width:break
    for j in range(number):
        for kk in range(-1,j if order_limit>1 else 0):
            # kk=-1 is the single; nonnegative kk forms each pair once.
            first=alternatives[j];second=-1;tl=al[j];th=ah[j]
            if kk>=0:second=alternatives[kk];tl^=al[kk];th^=ah[kk]
            value,lmask=candidate_cost(base,prior,pivots[:rank],tl,th,first,second,cost,mask,logical)
            candidate=bits.copy();candidate[first//64]^=np.uint64(1)<<np.uint64(first%64)
            if second>=0:candidate[second//64]^=np.uint64(1)<<np.uint64(second%64)
            for k in range(rank):
                if has_bit(tl,th,k):
                    v=pivots[k];candidate[v//64]^=np.uint64(1)<<np.uint64(v%64)
            count,_=insert_unique(candidate,value,lmask,stored,costs,masks,slots,count);generated+=1
    return count,generated,True,lv,lc

@njit(cache=False)
def choose(mass,class_cost,mode):
    probs=np.zeros(4,np.float64)
    for mask in range(16):
        for bit in range(4):
            if (mask>>bit)&1:probs[bit]+=mass[mask]
    marginal=0
    for bit in range(4):
        if probs[bit]>.5:marginal|=1<<bit
    if mode==1:return marginal
    if mode==2:return int(np.argmax(mass))
    if mode==3:return int(np.argmin(class_cost))
    chosen=0;risk_best=math.inf;tie=math.inf
    for mask in range(16):
        if mass[mask]>0:
            risk=0.
            for bit in range(4):risk+=1.-probs[bit] if ((mask>>bit)&1) else probs[bit]
            if risk<risk_best-1e-12 or (abs(risk-risk_best)<=1e-12 and class_cost[mask]<tie):
                chosen=mask;risk_best=risk;tie=class_cost[mask]
    return chosen

@njit(cache=False)
def add_degenerate_neighbors(s,sl,sh,reliability,low,high,logical,prior,width,stored,costs,masks,slots,count):
    """Enrich each best class witness with bounded zero-logical cycles.

    One shared basis and its zero-logical generators are reused across classes.
    Full-vector dedup avoids counting neighborhoods/proposals more than once.
    The expansion is explicitly class-preserving, not a wider logical list.
    """
    checks=len(s);bl,bh,cl,ch,pivots,selected,ordering,rank=reliability_basis(low,high,reliability,checks)
    if rank!=checks:return count,0
    gl=np.zeros(len(low),np.uint64);gh=gl.copy();valid=np.zeros(len(low),np.bool_)
    for v in range(len(low)):
        if not selected[v]:
            a,b,ok=solve_mask(low[v],high[v],bl,bh,cl,ch);delta=logical[v]
            for k in range(rank):
                if has_bit(a,b,k):delta^=logical[pivots[k]]
            if ok and delta==0:valid[v]=True;gl[v]=a;gh[v]=b
    champions=np.full(16,-1,np.int64);best=np.full(16,math.inf)
    for j in range(count):
        if costs[j]<best[masks[j]]:champions[masks[j]]=j;best[masks[j]]=costs[j]
    generated=0
    for mask in range(16):
        ix=champions[mask]
        if ix<0:continue
        packed_base=stored[ix].copy();base=np.zeros(len(prior),np.uint8)
        for v in range(len(prior)):base[v]=np.uint8((packed_base[v//64]>>np.uint64(v%64))&np.uint64(1))
        score=np.full(len(low),math.inf)
        for v in range(len(low)):
            if valid[v]:score[v],_=candidate_cost(base,prior,pivots,gl[v],gh[v],v,-1,best[mask],np.uint8(mask),logical)
        ordered=np.argsort(score,kind='mergesort');alternatives=np.empty(width,np.int64);number=0
        for v in ordered:
            if not math.isfinite(score[v]):break
            alternatives[number]=v;number+=1
            if number==width:break
        for j in range(number):
            for k in range(-1,j):
                v=alternatives[j];second=-1;tl=gl[v];th=gh[v]
                if k>=0:second=alternatives[k];tl^=gl[second];th^=gh[second]
                value,lmask=candidate_cost(base,prior,pivots,tl,th,v,second,best[mask],np.uint8(mask),logical)
                bits=packed_base.copy();bits[v//64]^=np.uint64(1)<<np.uint64(v%64)
                if second>=0:bits[second//64]^=np.uint64(1)<<np.uint64(second%64)
                for b in range(rank):
                    if has_bit(tl,th,b):
                        vv=pivots[b];bits[vv//64]^=np.uint64(1)<<np.uint64(vv%64)
                count,_=insert_unique(bits,value,lmask,stored,costs,masks,slots,count);generated+=1
    return count,generated

@njit(cache=False)
def disjoint_class_logmass(s,reliability,low,high,logical,prior,stored,costs,masks,count):
    """Exact mass of an adaptively chosen, restricted subspace per class.

    Disjoint physical supports make toggle likelihood ratios multiply exactly.
    This is a truncated posterior, not a claim to the complete partition sum.
    One anchor per class avoids overlap/double counting across subspaces.
    """
    bl,bh,cl,ch,pivots,selected,ordering,rank=reliability_basis(low,high,reliability,len(s))
    gl=np.zeros(len(low),np.uint64);gh=gl.copy();valid=np.zeros(len(low),np.bool_)
    for v in range(len(low)):
        if not selected[v]:
            a,b,ok=solve_mask(low[v],high[v],bl,bh,cl,ch);delta=logical[v]
            for k in range(rank):
                if has_bit(a,b,k):delta^=logical[pivots[k]]
            if ok and delta==0:gl[v]=a;gh[v]=b;valid[v]=True
    champions=np.full(16,-1,np.int64);best=np.full(16,math.inf);logmass=np.full(16,-math.inf)
    for j in range(count):
        if costs[j]<best[masks[j]]:best[masks[j]]=costs[j];champions[masks[j]]=j
    for mask in range(16):
        ix=champions[mask]
        if ix<0:continue
        base=np.zeros(len(prior),np.uint8)
        for v in range(len(prior)):base[v]=np.uint8((stored[ix,v//64]>>np.uint64(v%64))&np.uint64(1))
        gain=np.full(len(low),-math.inf)
        for v in range(len(low)):
            if valid[v]:
                cost,_=candidate_cost(base,prior,pivots[:rank],gl[v],gh[v],v,-1,best[mask],np.uint8(mask),logical)
                x=best[mask]-cost;gain[v]=max(0.,x)+math.log1p(math.exp(-abs(x)))
        ordering=np.argsort(-gain,kind='mergesort');used_low=np.uint64(0);used_high=np.uint64(0);value=-best[mask]
        for v in ordering:
            if gain[v]==-math.inf:break
            if (gl[v]&used_low)==0 and (gh[v]&used_high)==0:
                value+=gain[v];used_low|=gl[v];used_high|=gh[v]
        logmass[mask]=value
    return logmass

@njit(cache=False,parallel=True)
def posterior_batch(events,packed,ptr,variables,prior,logical,low,high,limits,dampings,scales,codes,
                    width,order_limit,refine_success,local_budget,mode,generator_mode,gate,degenerate_width,factorized_mass):
    n=len(events);proposals=len(codes);max_count=proposals*(1+width+width*(width-1)//2)
    max_count+=16*(degenerate_width+degenerate_width*(degenerate_width-1)//2)
    size=1
    while size<2*max_count:size*=2
    predictions=np.zeros((n,4),np.uint8);masses=np.zeros((n,16),np.float64)
    class_costs=np.full((n,16),math.inf);diagnostics=np.zeros((n,12),np.int32)
    for shot in prange(n):
        sl,sh=packed[shot,0],packed[shot,1]
        if sl==0 and sh==0:
            masses[shot,0]=1.;class_costs[shot,0]=0.;diagnostics[shot,0]=1;diagnostics[shot,3:6]=1;continue
        stored=np.empty((max_count,(len(prior)+63)//64),np.uint64)
        costs=np.empty(max_count,np.float64);masks=np.empty(max_count,np.uint8)
        slots=np.full(size,-1,np.int32);count=0;generated=0
        for p in range(proposals):
            estimate,posterior,solved,used,residual=bp_proposal(events[shot],sl,sh,ptr,variables,prior,logical,low,high,
                limits[p],dampings[p],scales[p],30.,codes[p])
            if p==0:
                diagnostics[shot,0]=int(solved);diagnostics[shot,1]=used;diagnostics[shot,2]=residual
                first_posterior=posterior.copy()
            diagnostics[shot,6]+=int(solved)
            if solved and not refine_success and p==0:
                cost=0.;mask=np.uint8(0)
                for v in range(len(prior)):
                    if estimate[v]:cost+=prior[v];mask^=logical[v]
                costs[0]=cost;masks[0]=mask;count=1;generated=1;break
            budget=local_budget if p==proposals-1 else 0
            count,added,success,lv,lc=add_ranked_list(events[shot],sl,sh,estimate,posterior,low,high,logical,prior,width,order_limit,budget,generator_mode,
                stored,costs,masks,slots,count)
            generated+=added;diagnostics[shot,10]+=int(success)
            if budget>0:diagnostics[shot,7]=int(success);diagnostics[shot,8]=lv;diagnostics[shot,9]=lc
            if p==0 and solved and gate>0 and count>0:
                # Selective proposal expansion depends on inference-only list
                # confidence and parity status, never on labels or row IDs.
                minimum=costs[:count].min();total=0.;bitmass=np.zeros(4)
                for j in range(count):
                    w=math.exp(-(costs[j]-minimum));total+=w
                    for bit in range(4):
                        if (masks[j]>>bit)&1:bitmass[bit]+=w
                confident=True
                for bit in range(4):
                    prob=bitmass[bit]/total
                    if max(prob,1.-prob)<gate:confident=False
                if confident:break
        if degenerate_width>0 and count>0 and (refine_success or diagnostics[shot,0]==0):
            count,added=add_degenerate_neighbors(events[shot],sl,sh,first_posterior,low,high,logical,prior,degenerate_width,stored,costs,masks,slots,count)
            generated+=added
        if count==0:
            # Global first proposal should always span this supplied full-rank DEM.
            masses[shot,0]=1.;class_costs[shot,0]=0.
        else:
            minimum=costs[:count].min()
            for j in range(count):
                mask=masks[j];masses[shot,mask]+=math.exp(-(costs[j]-minimum))
                class_costs[shot,mask]=min(class_costs[shot,mask],costs[j])
            masses[shot,:]/=masses[shot,:].sum()
            if factorized_mass and (refine_success or diagnostics[shot,0]==0):
                lm=disjoint_class_logmass(events[shot],first_posterior,low,high,logical,prior,stored,costs,masks,count)
                maximum=lm.max();masses[shot,:]=np.exp(lm-maximum);masses[shot,:]/=masses[shot,:].sum()
        decision=choose(masses[shot],class_costs[shot],mode)
        diagnostics[shot,3]=generated;diagnostics[shot,4]=count
        for mask in range(16):diagnostics[shot,5]+=int(math.isfinite(class_costs[shot,mask]))
        diagnostics[shot,11]=int(not math.isfinite(class_costs[shot,choose(masses[shot],class_costs[shot],1)]))
        for bit in range(4):predictions[shot,bit]=(decision>>bit)&1
    return predictions,masses,class_costs,diagnostics

class PosteriorDecoder:
    def __init__(self,circuits,config):
        self.config=dict(config);self.models={};self.last_details={}
        if not 1<=config['width']<=32:raise ValueError('Pilot width bound exceeded')
        if not 1<=len(config['proposals'])<=4:raise ValueError('Pilot proposal bound exceeded')
        if config.get('local_budget',0)>128:raise ValueError('Pilot local bound exceeded')
        if not 0<=config.get('degenerate_width',0)<=12:raise ValueError('Degeneracy pilot bound exceeded')
        if config.get('order',2) not in (0,1,2) or config.get('chunk_size',256)<1:raise ValueError('Invalid list configuration')
        if config.get('generator_mode',0) not in (0,1,2) or config.get('mode',1) not in (0,1,2,3):raise ValueError('Unknown selection rule')
        if not 0<=config.get('gate',0.)<1:raise ValueError('Invalid gate')
        for p in config['proposals']:
            if p['code'] not in (0,1,2,3) or not 1<=p['iterations']<=100 or not 0<=p['damping']<1 or not 0<p['scale']<=1:raise ValueError('Invalid BP proposal')
        for b,c in circuits.items():
            d=inspect_dem(c);s=SparseModel(d['H'],d['L'],d['p']);lo,hi=packed_columns(s.h)
            logical=(s.l.T@np.array([1,2,4,8],np.uint8)).astype(np.uint8)
            self.models[circuit_fingerprint(c)]=(s.ptr.astype(np.int32),s.variables.astype(np.int32),s.prior,logical,lo,hi)
    def decode(self,circuit,detector_events):
        events=validate_events(circuit,detector_events).astype(np.uint8,copy=False);key=circuit_fingerprint(circuit)
        if key not in self.models:raise ValueError('Unknown circuit fingerprint')
        c=self.config;ps=c['proposals'];parts=[]
        args=(np.array([p['iterations'] for p in ps]),np.array([p['damping'] for p in ps]),np.array([p['scale'] for p in ps]),np.array([p['code'] for p in ps]))
        for start in range(0,len(events),c.get('chunk_size',256)):
            x=events[start:start+c.get('chunk_size',256)]
            parts.append(posterior_batch(x,packed_events(x),*self.models[key],*args,c['width'],c.get('order',2),c.get('refine_success',True),c.get('local_budget',0),c.get('mode',1),c.get('generator_mode',0),c.get('gate',0.),c.get('degenerate_width',0),c.get('factorized_mass',False)))
        self.last_details={name:np.concatenate([p[i] for p in parts]) if parts else np.empty(shape,dtype=dtype)
            for i,(name,shape,dtype) in enumerate([('predictions',(0,4),np.uint8),('masses',(0,16),float),('class_costs',(0,16),float),('diagnostics',(0,12),np.int32)])}
        return self.last_details['predictions']

"""Milestone 3 derivative of our original bounded GF(2) list search.

At most 37 candidates for width=8, order=2. No QEC decoder implementation is
imported. All candidate representatives satisfy the syndrome by construction;
the base representative is checked explicitly before accepting a refinement.
"""
import math
import numpy as np
from numba import njit,prange


@njit(cache=False)
def has_bit(low,high,bit):
    if bit<64:return (low & (np.uint64(1)<<np.uint64(bit)))!=0
    return (high & (np.uint64(1)<<np.uint64(bit-64)))!=0


@njit(cache=False)
def solve_mask(low,high,bl,bh,cl,ch):
    outl=np.uint64(0);outh=np.uint64(0)
    for bit in range(len(bl)):
        if has_bit(low,high,bit):
            if bl[bit]==0 and bh[bit]==0:return outl,outh,False
            low^=bl[bit];high^=bh[bit];outl^=cl[bit];outh^=ch[bit]
    return outl,outh,low==0 and high==0


@njit(cache=False)
def reliability_basis(low,high,reliability,checks):
    # Stable ties preserve variable ordering, independent of batch order.
    order=np.argsort(np.abs(reliability),kind='mergesort')
    bl=np.zeros(checks,np.uint64);bh=bl.copy();cl=bl.copy();ch=bl.copy()
    pivots=np.full(checks,-1,np.int64);selected=np.zeros(len(low),np.bool_);rank=0
    for var in order:
        vl,vh=low[var],high[var];xl=np.uint64(0);xh=np.uint64(0)
        if rank<64:xl=np.uint64(1)<<np.uint64(rank)
        else:xh=np.uint64(1)<<np.uint64(rank-64)
        for bit in range(checks):
            if has_bit(vl,vh,bit):
                if bl[bit]!=0 or bh[bit]!=0:
                    vl^=bl[bit];vh^=bh[bit];xl^=cl[bit];xh^=ch[bit]
                else:
                    bl[bit]=vl;bh[bit]=vh;cl[bit]=xl;ch[bit]=xh
                    pivots[rank]=var;selected[var]=True;rank+=1;break
        if rank==checks:break
    return bl,bh,cl,ch,pivots,selected,order,rank


@njit(cache=False)
def candidate_cost(base,prior,pivots,cl,ch,first,second,base_cost,base_mask,logical_mask):
    cost=base_cost;mask=base_mask
    if first>=0:
        cost+=prior[first]*(1.-2.*base[first]);mask^=logical_mask[first]
    if second>=0:
        cost+=prior[second]*(1.-2.*base[second]);mask^=logical_mask[second]
    for j in range(len(pivots)):
        if has_bit(cl,ch,j):
            var=pivots[j];cost+=prior[var]*(1.-2.*base[var]);mask^=logical_mask[var]
    return cost,mask


@njit(cache=False)
def refine_one(syndrome,estimate,reliability,low,high,logical_mask,prior,ptr,variables,width,order_limit):
    checks=len(syndrome)
    bl,bh,cl,ch,pivots,selected,ordering,rank=reliability_basis(low,high,reliability,checks)
    if rank!=checks:return np.uint8(0),False,0,rank,False
    dl=np.uint64(0);dh=np.uint64(0)
    for bit in range(checks):
        if syndrome[bit]:
            if bit<64:dl^=np.uint64(1)<<np.uint64(bit)
            else:dh^=np.uint64(1)<<np.uint64(bit-64)
    for var in range(len(estimate)):
        if estimate[var]:dl^=low[var];dh^=high[var]
    xl,xh,success=solve_mask(dl,dh,bl,bh,cl,ch)
    if not success:return np.uint8(0),False,0,rank,False
    base=estimate.copy()
    for j in range(checks):
        if has_bit(xl,xh,j):base[pivots[j]]^=1
    base_cost=0.;base_mask=np.uint8(0);ol=np.uint64(0);oh=np.uint64(0)
    for var in range(len(base)):
        if base[var]:
            base_cost+=prior[var];base_mask^=logical_mask[var];ol^=low[var];oh^=high[var]
    for bit in range(checks):
        if has_bit(ol,oh,bit)!=bool(syndrome[bit]):return np.uint8(0),False,0,rank,False
    max_candidates=1+width+width*(width-1)//2
    costs=np.empty(max_candidates,np.float64);masks=np.empty(max_candidates,np.uint8)
    costs[0]=base_cost;masks[0]=base_mask;count=1
    alternatives=np.empty(width,np.int64);al=np.empty(width,np.uint64);ah=al.copy();number=0
    if order_limit>0:
        for var in ordering:
            if not selected[var]:
                a,b,ok=solve_mask(low[var],high[var],bl,bh,cl,ch)
                if ok:
                    alternatives[number]=var;al[number]=a;ah[number]=b;number+=1
                    if number==width:break
        # Exact selective shortcut: if every generator has zero logical effect,
        # all singles/pairs share the base class, regardless of their likelihoods.
        # No confidence threshold or approximation is used to skip these lists.
        uniform=True
        for j in range(number):
            delta=logical_mask[alternatives[j]]
            for bit in range(checks):
                if has_bit(al[j],ah[j],bit):delta^=logical_mask[pivots[bit]]
            if delta!=0:
                uniform=False;break
        if uniform:return base_mask,True,1,rank,False
        for j in range(number):
            cost,mask=candidate_cost(base,prior,pivots,al[j],ah[j],alternatives[j],-1,base_cost,base_mask,logical_mask)
            costs[count]=cost;masks[count]=mask;count+=1
        if order_limit>1:
            for j in range(number):
                for k in range(j):
                    cost,mask=candidate_cost(base,prior,pivots,al[j]^al[k],ah[j]^ah[k],alternatives[j],alternatives[k],base_cost,base_mask,logical_mask)
                    costs[count]=cost;masks[count]=mask;count+=1
    minimum=costs[:count].min();mass=np.zeros(16,np.float64);class_cost=np.full(16,math.inf)
    for j in range(count):
        mask=masks[j];mass[mask]+=math.exp(-(costs[j]-minimum));class_cost[mask]=min(class_cost[mask],costs[j])
    probabilities=np.zeros(4,np.float64);total=mass.sum()
    for mask in range(16):
        for bit in range(4):
            if (mask>>bit)&1:probabilities[bit]+=mass[mask]/total
    unconstrained=0
    for bit in range(4):
        if probabilities[bit]>.5:unconstrained|=1<<bit
    # Minimize truncated-posterior expected bit loss among classes with an actual
    # candidate witness. Every selected class therefore has a syndrome-valid representative.
    chosen=0;best_risk=math.inf;tie_cost=math.inf
    for mask in range(16):
        if mass[mask]>0:
            risk=0.
            for bit in range(4):risk+=(1.-probabilities[bit]) if ((mask>>bit)&1) else probabilities[bit]
            if risk<best_risk-1e-12 or (abs(risk-best_risk)<=1e-12 and class_cost[mask]<tie_cost):
                best_risk=risk;tie_cost=class_cost[mask];chosen=mask
    return np.uint8(chosen),True,count,rank,mass[unconstrained]==0

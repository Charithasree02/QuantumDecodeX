"""Milestone 3: fused min-sum BP, packed parity and in-kernel bounded search.

Float64 arithmetic, edge order, damping and first-parity-success stopping match
Milestone 2. Original modules are retained unchanged as the reference.
"""
import math
import numpy as np
from numba import njit,prange
from .model import SparseModel
from .search_fast import refine_one
from .harness import inspect_dem,circuit_fingerprint,validate_events


@njit(cache=False,inline='always')
def popcount(x):
    count=0
    while x!=0:
        x &= x-np.uint64(1);count+=1
    return count


def packed_columns(h):
    low=np.zeros(h.shape[1],np.uint64);high=low.copy()
    for bit,row in enumerate(h):
        if bit<64:low|=row.astype(np.uint64)<<np.uint64(bit)
        else:high|=row.astype(np.uint64)<<np.uint64(bit-64)
    return low,high


def packed_events(events):
    a=np.zeros((len(events),16),np.uint8)
    a[:,:9]=np.packbits(events,axis=1,bitorder='little')
    return a.view('<u8').astype(np.uint64,copy=False)


@njit(cache=False,parallel=True)
def fused_decode(events,syndromes,ptr,variables,prior,logical,low,high,iterations,damping,scale,clip,
                 tolerance,stable_steps,width,order,do_refine):
    n,m=len(events),len(prior);edges=len(variables)
    out=np.zeros((n,4),np.uint8);solved=np.zeros(n,np.bool_)
    used=np.zeros(n,np.int32);residuals=np.zeros(n,np.int32)
    refined=np.zeros(n,np.bool_);candidate_counts=np.zeros(n,np.int32)
    restricted=np.zeros(n,np.bool_);stagnated=np.zeros(n,np.bool_)
    for shot in prange(n):
        target_low,target_high=syndromes[shot,0],syndromes[shot,1]
        best_res=popcount(target_low)+popcount(target_high);best_cost=0.;best_mask=np.uint8(0)
        if best_res==0:
            solved[shot]=True
            continue
        r=np.zeros(edges,np.float64);q=np.empty(edges,np.float64)
        for e in range(edges):q[e]=prior[variables[e]]
        hard=np.zeros(m,np.uint8);best=np.zeros(m,np.uint8);posterior=prior.copy();stable=0
        for iteration in range(iterations):
            posterior[:]=prior;maxchange=0.
            # Each edge's new check message and contribution to posterior are fused.
            # The same check/edge accumulation order is retained for float64 equivalence.
            for c in range(len(ptr)-1):
                start,end=ptr[c],ptr[c+1];sign=-1. if events[shot,c] else 1.
                minimum=math.inf;second=math.inf;argmin=-1
                for e in range(start,end):
                    value=q[e]
                    if value<0:sign=-sign
                    a=abs(value)
                    if a<minimum:second=minimum;minimum=a;argmin=e
                    elif a<second:second=a
                for e in range(start,end):
                    edge_sign=-sign if q[e]<0 else sign
                    magnitude=min(clip,scale*(second if e==argmin else minimum))
                    fresh=edge_sign*magnitude
                    new=damping*r[e]+(1.-damping)*fresh
                    maxchange=max(maxchange,abs(new-r[e]));r[e]=new
                    posterior[variables[e]]+=new
            observed_low=np.uint64(0);observed_high=np.uint64(0);mask=np.uint8(0);cost=0.
            for j in range(m):
                hard[j]=1 if posterior[j]<0 else 0
                if hard[j]:
                    cost+=prior[j];observed_low^=low[j];observed_high^=high[j];mask^=logical[j]
            residual=popcount(observed_low^target_low)+popcount(observed_high^target_high)
            used[shot]=iteration+1
            if residual<best_res or (residual==best_res and cost<best_cost):
                best_res=residual;best_cost=cost;best_mask=mask;best[:]=hard
            if residual==0:
                solved[shot]=True;break
            stable=stable+1 if maxchange<tolerance else 0
            if stable>=stable_steps:
                stagnated[shot]=True;break
            for e in range(edges):
                value=posterior[variables[e]]-r[e]
                q[e]=max(-clip,min(clip,value))
        residuals[shot]=best_res
        if do_refine and not solved[shot]:
            refined_mask,success,count,rank,restrict=refine_one(events[shot],best,posterior,
                low,high,logical,prior,ptr,variables,width,order)
            refined[shot]=success;candidate_counts[shot]=count;restricted[shot]=restrict
            if success:best_mask=refined_mask
        for bit in range(4):out[shot,bit]=(best_mask>>bit)&1
    return out,solved,used,residuals,refined,candidate_counts,restricted,stagnated


class FastPhysicsDecoder:
    def __init__(self,circuits,iterations=30,damping=.35,scale=.8,clip=30.,width=8,order=2,
                 chunk_size=2048,refine=True,tolerance=1e-7,stable_steps=3):
        if iterations<1 or not 0<=damping<1 or not 0<scale<=1 or clip<=0 or not np.isfinite(clip):
            raise ValueError('Invalid BP configuration')
        if not 1<=width<=12 or order not in (0,1,2) or chunk_size<1:
            raise ValueError('Milestone 3 bounded configuration exceeded')
        self.iterations=iterations;self.damping=damping;self.scale=scale;self.clip=clip
        self.width=width;self.order=order;self.chunk_size=chunk_size;self.refine=refine
        self.tolerance=tolerance;self.stable_steps=stable_steps;self.models={};self.last_diagnostics={}
        for b,circuit in circuits.items():
            d=inspect_dem(circuit);model=SparseModel(d['H'],d['L'],d['p'])
            lo,hi=packed_columns(model.h);logical=(model.l.T@np.array([1,2,4,8],np.uint8)).astype(np.uint8)
            self.models[circuit_fingerprint(circuit)]=(model.ptr.astype(np.int32),model.variables.astype(np.int32),
                model.prior,logical,lo,hi)

    def decode(self,circuit,detector_events):
        a=validate_events(circuit,detector_events).astype(np.uint8,copy=False)
        key=circuit_fingerprint(circuit)
        if key not in self.models:raise ValueError('Unknown circuit fingerprint')
        model=self.models[key];packed=packed_events(a)
        predictions=np.empty((len(a),4),np.uint8);parts=[]
        for start in range(0,len(a),self.chunk_size):
            result=fused_decode(a[start:start+self.chunk_size],packed[start:start+self.chunk_size],*model,
                self.iterations,self.damping,self.scale,self.clip,self.tolerance,self.stable_steps,
                self.width,self.order,self.refine)
            predictions[start:start+len(result[0])]=result[0];parts.append(result[1:])
        names=['bp_syndrome_consistent','iterations','residual_check_count','refined','candidate_counts','restricted','message_stagnated']
        self.last_diagnostics={name:np.concatenate([p[i] for p in parts]) if parts else np.empty(0,
            dtype=bool if i in (0,3,5,6) else np.int32) for i,name in enumerate(names)}
        return predictions

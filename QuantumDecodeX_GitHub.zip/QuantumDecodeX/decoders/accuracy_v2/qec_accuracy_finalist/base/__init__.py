"""Original QEC finalist runtime; no training/test rows are used here."""

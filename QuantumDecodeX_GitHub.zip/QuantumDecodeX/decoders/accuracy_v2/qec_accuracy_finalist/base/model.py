"""Original sparse model builder, frozen from earlier milestones."""
import numpy as np
from .harness import binary_array
class SparseModel:
    def __init__(self,h,l,p):
        h=binary_array(h,name='H').astype(np.uint8);l=binary_array(l,name='L').astype(np.uint8)
        p=np.asarray(p,dtype=np.float64)
        if h.ndim!=2 or l.shape!=(4,h.shape[1]) or p.shape!=(h.shape[1],):raise ValueError('Model shape mismatch')
        if not np.isfinite(p).all() or not ((p>0)&(p<.5)).all():raise ValueError('Bad prior')
        rows,variables=np.nonzero(h)
        self.ptr=np.concatenate([[0],np.cumsum(np.bincount(rows,minlength=len(h)))]).astype(np.int64)
        self.variables=variables.astype(np.int64);self.prior=np.log1p(-p)-np.log(p)
        self.h=h;self.l=l;self.p=p

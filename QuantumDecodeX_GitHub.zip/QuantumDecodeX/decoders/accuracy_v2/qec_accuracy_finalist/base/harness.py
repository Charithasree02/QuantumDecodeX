"""Standalone strict interface checks; no project paths or data loaders."""
import hashlib
import numpy as np
from .dem import problem_info

def binary_array(value,shape=None,name='array'):
    a=np.asarray(value)
    if shape is not None and a.shape!=shape:raise ValueError(f'{name}: shape {a.shape}, expected {shape}')
    if a.dtype.kind not in 'buif' or not np.isfinite(a).all() or not np.isin(a,(0,1)).all():raise ValueError(f'{name}: expected finite binary numeric values')
    return a
def circuit_fingerprint(circuit):return hashlib.sha256(str(circuit).encode('utf-8')).hexdigest()
def inspect_dem(circuit):
    d=problem_info(circuit);h,l,p=(d[k] for k in ('H','L','p'))
    binary_array(h,(70,len(p)),'H');binary_array(l,(4,len(p)),'L')
    if p.ndim!=1 or not np.isfinite(p).all() or not ((p>0)&(p<.5)).all():raise ValueError('Invalid DEM prior')
    return d
def validate_events(circuit,events):
    a=np.asarray(events)
    if a.ndim!=2 or circuit.num_detectors!=70 or circuit.num_observables!=4:raise ValueError('Unsupported dimensions')
    return binary_array(a,(len(a),70),'detector_events')
def validate_predictions(predictions,shots):return binary_array(predictions,(shots,4),'predictions').astype(np.uint8,copy=False)

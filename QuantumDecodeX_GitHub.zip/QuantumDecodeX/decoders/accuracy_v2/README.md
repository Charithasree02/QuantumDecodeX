# Best validated accuracy decoder

This is the exact frozen decoder used for submission_v2.csv. Independent native
confirmation LER: 0.03591250. Participant-reported Kaggle CSV score: 0.03703.
Local runtime is high; see the root README before choosing executable hand-in.

Install requirements.txt and import decoder.decode(circuit, detector_events).
Input binary (shots,70); output uint8 (shots,4), L0..L3. Both circuit assets and
all inference source/configuration are included. No weights or training needed.

# Efficient advanced physics decoder

Independent native confirmation LER: 0.03878125. This preserves the newer
failure-only two-proposal decoder. It had the best provisional local median
speed-adjusted score in the saved comparison, with substantial timing drift;
it is not the model used for submission_v2.csv.

Install requirements.txt and import decoder.decode(circuit, detector_events).
All inference source, configurations and both circuits are included. No weights.

"""Frozen custom physics finalist; no training, labels, IDs or network."""
from pathlib import Path
import sys,os,json
import numpy as np
import stim,numba
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from qec_efficient_finalist.posterior import PosteriorDecoder
from qec_efficient_finalist.base.harness import circuit_fingerprint,validate_predictions
CONFIG=json.loads((BASE/'config.json').read_text())
numba.set_num_threads(min(int(os.environ.get('QEC_NUM_THREADS',12)),numba.config.NUMBA_NUM_THREADS))
circuits={b:stim.Circuit.from_file(BASE/'assets'/f'{b}_circuit.stim') for b in 'XZ'}
for b,c in circuits.items():
    if circuit_fingerprint(c)!=CONFIG['circuit_fingerprints'][b]:raise ValueError('Circuit asset changed')
model=PosteriorDecoder(circuits,CONFIG['physics'])
for c in circuits.values():model.decode(c,np.zeros((1,70),bool))
def decode(circuit,detector_events):
    return validate_predictions(model.decode(circuit,detector_events),len(detector_events))

# Earlier fast pure-physics fallback

Frozen 79-candidate BP/GF(2) decoder. Saved 40k independent native LER: 0.04820.
This retains the earlier fast pure implementation without PyTorch or weights.

Install requirements.txt and import decoder.decode(circuit, detector_events).
Both circuit assets and all inference source/configuration are included.

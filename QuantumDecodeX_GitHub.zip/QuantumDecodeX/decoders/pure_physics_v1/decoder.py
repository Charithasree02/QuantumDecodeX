"""Frozen offline finalist. Import initializes assets; decode returns arrays only."""
from pathlib import Path
import os
import sys
import json
import hashlib
import numpy as np
import stim
import numba

BASE=Path(__file__).resolve().parent
if str(BASE) not in sys.path:sys.path.insert(0,str(BASE))
from qec_pure.fast_physics import FastPhysicsDecoder
from qec_pure.harness import circuit_fingerprint,validate_predictions

CONFIG=json.loads((BASE/'config.json').read_text(encoding='utf-8'))
requested=int(os.environ.get('QEC_NUM_THREADS',CONFIG['numba_threads']))
if requested<1:raise ValueError('QEC_NUM_THREADS must be positive')
ACTIVE_THREADS=min(requested,numba.config.NUMBA_NUM_THREADS)
numba.set_num_threads(ACTIVE_THREADS)
circuits={b:stim.Circuit.from_file(BASE/'assets'/f'{b}_circuit.stim') for b in 'XZ'}
for b,c in circuits.items():
    if circuit_fingerprint(c)!=CONFIG['circuit_fingerprints'][b]:raise ValueError('Circuit asset changed')
model=FastPhysicsDecoder(circuits,**CONFIG['physics'])
if CONFIG['hybrid'] is not None:
    import torch
    torch.set_num_threads(CONFIG['hybrid']['torch_threads'])
    if torch.get_num_interop_threads()!=1:
        try:torch.set_num_interop_threads(1)
        except RuntimeError:pass  # Existing host pool is harmless to eager-model correctness; log actual state in verification.
    from qec_pure.mlp import MLPDecoder
    from qec_pure.selective import SelectiveHybridDecoder
    for b in 'XZ':
        raw=(BASE/'weights'/f'{b}_mlp.pt').read_bytes()
        if hashlib.sha256(raw).hexdigest()!=CONFIG['hybrid']['checkpoint_sha256'][b]:raise ValueError('Checkpoint changed')
    mlp=MLPDecoder.from_directory(BASE/'weights',circuits,CONFIG['hybrid']['batch_size'])
    model=SelectiveHybridDecoder(model,mlp,CONFIG['hybrid']['threshold'])
# Initialize the complete numeric signature at import; no simulation/network/training.
for c in circuits.values():model.decode(c,np.zeros((1,70),bool))

def decode(circuit,detector_events):
    return validate_predictions(model.decode(circuit,detector_events),len(detector_events))

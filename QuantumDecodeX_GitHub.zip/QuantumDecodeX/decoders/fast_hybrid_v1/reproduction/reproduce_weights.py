"""Reproduce the team's frozen small MLPs; never train on test/sealed data."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import numpy as np
import torch

def state_hash(state):
    h=hashlib.sha256()
    for key,value in state.items():h.update(key.encode());h.update(value.detach().cpu().numpy().tobytes())
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--train',type=Path,required=True,help='Original labeled train.csv or train.csv.gz');args=p.parse_args()
    base=Path(__file__).resolve().parents[1];sys.path.insert(0,str(base))
    from qec_hybrid.mlp import SmallMLP
    config=json.loads((base/'reproduction/training_config.json').read_text());assets=json.loads((base/'config.json').read_text())
    args.out.mkdir(parents=True,exist_ok=False)
    torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    data=np.loadtxt(args.train,delimiter=',',skiprows=1,usecols=range(2,76),dtype=np.uint8)
    if data.shape!=(200000,74) or not np.isin(data,[0,1]).all():raise ValueError('Unexpected original training data')
    report={}
    for bi,b in enumerate('XZ'):
        a=data[bi*100000:(bi+1)*100000];events=a[:,:70].astype(bool);labels=a[:,70:]
        perm=np.random.default_rng(config['split_seed']+bi).permutation(100000)
        train,tune=perm[:80000],perm[80000:]
        x=torch.from_numpy(events[train].astype(np.float32));y=torch.from_numpy(labels[train].astype(np.float32))
        tx=events[tune];ty=labels[tune]
        seed=config['training_seed']+bi;torch.manual_seed(seed)
        model=SmallMLP(config['hidden_width'],config['hidden_layers'])
        optimizer=torch.optim.AdamW(model.parameters(),lr=config['learning_rate'],weight_decay=config['weight_decay'])
        criterion=torch.nn.BCEWithLogitsLoss();generator=torch.Generator().manual_seed(seed+100)
        best_key=(float('inf'),float('inf'));best_state=None;best_epoch=None
        for epoch in range(1,config['epochs']+1):
            model.train();order=torch.randperm(len(x),generator=generator)
            for start in range(0,len(order),config['batch_size']):
                ix=order[start:start+config['batch_size']];optimizer.zero_grad(set_to_none=True)
                loss=criterion(model(x[ix]),y[ix]);loss.backward();optimizer.step()
            model.eval()
            with torch.inference_mode():
                logits=torch.cat([model(torch.from_numpy(tx[i:i+config['inference_batch_size']].astype(np.float32))) for i in range(0,len(tx),config['inference_batch_size'])])
                bce=criterion(logits,torch.from_numpy(ty.astype(np.float32))).item()
                ler=float(np.mean((logits.numpy()>0)!=ty))
            if (ler,bce)<best_key:
                best_key=(ler,bce);best_epoch=epoch;best_state={k:v.detach().clone() for k,v in model.state_dict().items()}
        checkpoint={'state_dict':best_state,'width':config['hidden_width'],'layers':config['hidden_layers'],'basis':b,
            'circuit_fingerprint':assets['circuit_fingerprints'][b],'selected_epoch':best_epoch,'model_seed':seed}
        torch.save(checkpoint,args.out/f'{b}_mlp.pt')
        original=torch.load(base/'weights'/f'{b}_mlp.pt',map_location='cpu',weights_only=True)
        report[b]={'selected_epoch':best_epoch,'tuning_ler':best_key[0],'tensor_hash':state_hash(best_state),
            'original_tensor_hash':state_hash(original['state_dict']),
            'all_tensors_exact':all(torch.equal(best_state[k],original['state_dict'][k]) for k in best_state)}
    (args.out/'reproduction_result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
    if not all(v['all_tensors_exact'] for v in report.values()):raise AssertionError('Exact training replay differs; do not overwrite frozen weights')

if __name__=='__main__':main()

# Earlier fast hybrid

Own basis-specific small MLP confidence gate plus our custom physics decoder.
Own trained X/Z weights and the complete training replay recipe are included.
Participant-reported v1 Kaggle score: 0.04833. Saved 40k independent native LER:
0.04820. See root README for measured timing and exact environment limitations.

Install requirements.txt with the CPU PyTorch index described in the root README.
Import decoder.decode(circuit, detector_events). Assets/weights resolve relative
to this folder. Reproduce weights using reproduction/reproduce_weights.py with
--train YOUR_ORIGINAL_TRAIN.csv --out NEW_OUTPUT_DIRECTORY. No train CSV bundled.

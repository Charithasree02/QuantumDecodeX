"""Small original MLP, trained by this project; four marginal logits."""
from pathlib import Path

import numpy as np
import torch
from torch import nn

from .harness import circuit_fingerprint, validate_events, validate_predictions


class SmallMLP(nn.Module):
    def __init__(self,width=128,layers=2):
        super().__init__()
        modules=[]; size=70
        for _ in range(layers):
            modules.extend([nn.Linear(size,width),nn.ReLU()]);size=width
        modules.append(nn.Linear(size,4))
        self.network=nn.Sequential(*modules)

    def forward(self,x):
        return self.network(x)


class MLPDecoder:
    def __init__(self,models,circuits,batch_size=4096):
        self.models = {b:m.cpu().eval() for b,m in models.items()}
        self.fingerprints = {circuit_fingerprint(c):b for b,c in circuits.items()}
        self.batch_size=batch_size
        if batch_size <= 0:
            raise ValueError('batch_size must be positive')

    @torch.inference_mode()
    def logits(self,circuit,detector_events):
        a=validate_events(circuit,detector_events)
        key=circuit_fingerprint(circuit)
        if key not in self.fingerprints:
            raise ValueError('Unrecognized circuit fingerprint; no silent basis substitution')
        model=self.models[self.fingerprints[key]]
        out=np.empty((len(a),4),dtype=np.float32)
        for start in range(0,len(a),self.batch_size):
            x=torch.from_numpy(np.array(a[start:start+self.batch_size],dtype=np.float32,copy=True))
            out[start:start+len(x)]=model(x).numpy()
        if not np.isfinite(out).all():
            raise ValueError('Nonfinite model logits')
        return out

    def decode(self,circuit,detector_events):
        # Zero logits deterministically map to 0, equivalent to probability > 0.5.
        out=(self.logits(circuit,detector_events)>0).astype(np.uint8)
        return validate_predictions(out,len(detector_events))

    @classmethod
    def from_directory(cls,directory,circuits,batch_size=4096):
        models={}
        for b in 'XZ':
            checkpoint=torch.load(Path(directory)/f'{b}_mlp.pt',map_location='cpu',weights_only=True)
            if checkpoint['circuit_fingerprint']!=circuit_fingerprint(circuits[b]):
                raise ValueError('Checkpoint circuit fingerprint mismatch')
            m=SmallMLP(checkpoint['width'],checkpoint['layers'])
            m.load_state_dict(checkpoint['state_dict']);models[b]=m
        return cls(models,circuits,batch_size)

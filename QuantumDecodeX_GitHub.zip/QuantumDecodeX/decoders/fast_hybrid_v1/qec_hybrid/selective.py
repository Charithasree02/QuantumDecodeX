"""Small selective wrapper around this team's frozen MLP and physics decoder."""
import numpy as np
from .harness import circuit_fingerprint,validate_predictions


class SelectiveHybridDecoder:
    def __init__(self,physics,mlp,threshold=.99):
        if not .5<threshold<1:raise ValueError('Confidence threshold must lie between .5 and 1')
        self.physics=physics;self.mlp=mlp;self.threshold=threshold;self.routes={}

    def decode(self,circuit,events):
        logits=self.mlp.logits(circuit,events)
        probability=1./(1.+np.exp(-np.clip(logits,-50,50)))
        confident=np.minimum(probability,1-probability).max(axis=1)<=1-self.threshold
        confident &= np.any(events,axis=1)
        out=(logits>0).astype(np.uint8)
        out[~confident]=self.physics.decode(circuit,events[~confident])
        self.routes[circuit_fingerprint(circuit)]=int(confident.sum())
        return validate_predictions(out,len(events))

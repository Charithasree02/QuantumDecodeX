# Provenance and compliance scope

BP, candidate search, strict validation, MLP and selective routing were written
for this project in Milestones 1–4. Packaging changes only imports, dependency
boundaries, asset locations and compilation-cache policy; numerical model choices
are frozen. No existing QEC decoder package/code is used. dem.py is the explicitly
provided organizer problem_info helper under the attached MIT license, not a
third-party decoder. Circuit assets are the supplied competition circuits.

The hybrid weights, if present, were trained by this project on the public labeled
training CSV; no externally pretrained decoder weights were used. Inference never
loads row IDs, public/test CSVs, training labels, saved predictions, or simulator
labels. Only the supplied circuit, detector array, frozen circuit assets and
optional own model weights are available to decode. No test-row lookup exists.

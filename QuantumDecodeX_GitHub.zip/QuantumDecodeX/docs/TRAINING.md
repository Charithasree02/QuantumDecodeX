# Reproduce the original hybrid MLP weights

Only `fast_hybrid_v1` needs trained weights. Both included `.pt` files were trained
from scratch by this project on the supplied labeled competition training data.
No externally pretrained QEC decoder weights are used. The other three decoders
are physics models and require no training/checkpoints.

Install requirements-hybrid.txt. Keep the original `train.csv` (or its gzip copy)
locally in data/. The original file has 200,000 rows, first 100,000 X and then
100,000 Z, columns id,basis,D0..D69,L0..L3. It is not included in this code export.

```bash
python decoders/fast_hybrid_v1/reproduction/reproduce_weights.py --train data/train.csv --out results/rebuilt_weights
```

The output directory must not already exist. Original checkpoints are never
overwritten. The script uses the original 80k/20k train/tuning split per basis,
seeds, 70→128→128→4 architecture, AdamW, BCE loss and 12 epochs. Configuration and
split indices are included under `decoders/fast_hybrid_v1/reproduction/`.

The replay checks every rebuilt tensor against its frozen counterpart and writes
`reproduction_result.json`. Exact equality was verified in the original pinned
Windows Python 3.11/Torch 2.6 CPU environment. Other numerical environments may
differ and require revalidation. Inference reads only its own circuit assets,
configuration and hash-checked weights; it never reads the training CSV.

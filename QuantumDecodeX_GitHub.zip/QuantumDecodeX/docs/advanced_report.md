# Advanced decoder phase report

The best frozen accuracy candidate achieved **0.03591250 LER** on 40,000 entirely fresh native Stim shots, versus 0.04820000 for the preserved decoder on exactly those shots. This is a 25.49% relative reduction. The top-2 target below 0.03387 was not reached. No new Kaggle predictions or upload were made. The successful Milestone 5 submission remains intact.

## Fresh confirmation, not tuning

The two source/configuration packages were frozen and hashed before seeds 2026116401/2026116402 generated 20,000 shots per basis. All model prediction files were written before scoring the new labels. No parameter, checkpoint or threshold was changed afterward. Full provenance, predictions and whole-shot bootstrap evidence are in experiments/confirmation/.

| Decoder | X LER | Z LER | Combined | Absolute 95% CI | Paired absolute reduction vs pure, 95% CI | Seconds / 40k shots | Peak process RSS MiB |
|---|---:|---:|---:|---|---|---:|---:|
| pure | 0.04911250 | 0.04728750 | 0.04820000 | [0.04664359, 0.04982516] | [0.00000000, 0.00000000] | 7.553 | 520.53 |
| hybrid | 0.04911250 | 0.04728750 | 0.04820000 | [0.04664359, 0.04982516] | [0.00000000, 0.00000000] | 7.204 | 526.20 |
| accuracy_finalist | 0.03658750 | 0.03523750 | 0.03591250 | [0.03458734, 0.03731266] | [0.01119375, 0.01344375] | 111.749 | 538.44 |
| efficient_finalist | 0.03925000 | 0.03831250 | 0.03878125 | [0.03736875, 0.04021891] | [0.00836234, 0.01046875] | 21.373 | 535.77 |

Paired intervals resample whole shots within basis (2,000 replicates), retaining correlation among the four logical bits. Absolute intervals resample the per-shot 0..4 wrong-bit histogram within each basis (5,000 replicates), which is equivalent for this statistic. They quantify simulation uncertainty, not leaderboard/private-distribution uncertainty. All shots, including BP failures, are scored. Historical reference LER 0.04795375 is retained, but paired comparisons correctly use the reference predictions on this new set.

## Failure analysis

The development pilot used 6,000 new native shots per basis (seeds 2026116001/2026116002). Preserved pure and hybrid predictions were identical on this pilot, with combined LER 0.04672917. Their configurations and the previous successful CSV were never edited.

| Basis / group | Shots | Wrong logical bits | Conditional bit LER | Share of basis wrong bits |
|---|---:|---:|---:|---:|
| X / syndrome_weight_0_0 | 257 | 0 | 0.000000 | 0.00% |
| X / syndrome_weight_1_2 | 563 | 8 | 0.003552 | 0.70% |
| X / syndrome_weight_3_4 | 790 | 42 | 0.013291 | 3.67% |
| X / syndrome_weight_5_8 | 2124 | 211 | 0.024835 | 18.43% |
| X / syndrome_weight_9_12 | 1477 | 423 | 0.071598 | 36.94% |
| X / syndrome_weight_13_20 | 763 | 433 | 0.141874 | 37.82% |
| X / syndrome_weight_21_70 | 26 | 28 | 0.269231 | 2.45% |
| X / bp_consistent | 4447 | 221 | 0.012424 | 19.30% |
| X / bp_failed | 1553 | 924 | 0.148744 | 80.70% |
| X / search_multi | 878 | 749 | 0.213269 | 65.41% |
| X / search_uniform_or_skipped | 5122 | 396 | 0.019328 | 34.59% |
| Z / syndrome_weight_0_0 | 291 | 0 | 0.000000 | 0.00% |
| Z / syndrome_weight_1_2 | 540 | 5 | 0.002315 | 0.46% |
| Z / syndrome_weight_3_4 | 899 | 34 | 0.009455 | 3.10% |
| Z / syndrome_weight_5_8 | 2081 | 222 | 0.026670 | 20.22% |
| Z / syndrome_weight_9_12 | 1442 | 388 | 0.067268 | 35.34% |
| Z / syndrome_weight_13_20 | 716 | 414 | 0.144553 | 37.70% |
| Z / syndrome_weight_21_70 | 31 | 35 | 0.282258 | 3.19% |
| Z / bp_consistent | 4450 | 180 | 0.010112 | 16.39% |
| Z / bp_failed | 1550 | 918 | 0.148065 | 83.61% |
| Z / search_multi | 867 | 779 | 0.224625 | 70.95% |
| Z / search_uniform_or_skipped | 5133 | 319 | 0.015537 | 29.05% |

BP failures account for 1,842 of 2,243 wrong bits (82.12%); syndrome-consistent BP accounts for 401 (17.88%). Thus parity success is not logical success, and spending all additional compute on already successful BP cases cannot fix most errors. Syndromes of weight 9 or more account for most remaining wrong bits. The full per-detector conditional LERs and recurring detector patterns are retained in experiments/pilot_001/failure_analysis.json, along with all per-shot convergence/iteration/residual/search arrays. Detector conditions overlap and are not causal attributions. Rare high-weight patterns have too few repeated observations to infer a reliable lookup policy. No pattern table is used at inference.

The original 79-candidate failure-only list has a label-assisted support-oracle bit error fraction 0.018375 on development: 882 of 2,243 actual wrong bits cannot be corrected within its available per-bit support; the remaining 1,361 have an alternative with the correct bit but are ranked incorrectly. This diagnostic is artificially restricted by skipped BP-success cases and includes negligible-probability candidates; it is neither an achievable decoder nor a lower bound on optimal LER.

Searching all shots and expanding to 301 candidates reduces the support-oracle error fraction to about 0.00554, but actual LER only to 0.045375. A large support improvement with a small actual improvement identifies posterior ranking/mass, not merely list truncation, as a bottleneck. Selecting generators by original physical likelihood improves a same-size 301 list to 0.0421875. Combining schedules and reserving representatives for logical alternatives improves further. The three-schedule list contains the true logical class on every pilot shot, yet still errs: presence in the list is insufficient.

Exact full-vector deduplication removes roughly 22% repeated configurations from the first two-schedule union. Logical classes may contain multiple distinct configurations and their probabilities must be added, but copies of the same physical configuration must not be counted twice. On that union, bitwise marginal decisions give 0.04183333 versus 0.04391667 for the single minimum-cost representative. Minimum-cost class and full candidate mass comparisons are retained separately.

## Complete development comparison

All rows below used the same 12,000-shot development set. One post-compilation timing per pilot is exploratory, not an official benchmark. Paired development intervals do not account for choosing among experiments; only the fresh confirmation supports promotion. CSV contains per-basis LER, memory and intervals for every row.

| Approach | Combined LER | Seconds / 12k shots | Paired LER reduction 95% CI |
|---|---:|---:|---|
| pure | 0.04672917 | 1.899 | reference |
| hybrid | 0.04672917 | 2.091 | reference |
| reference_equivalence | 0.04672917 | 3.224 | [0.000000, 0.000000] |
| all_shots_79 | 0.04597917 | 3.918 | [0.000104, 0.001375] |
| all_shots_301 | 0.04537500 | 4.438 | [-0.000188, 0.002833] |
| ensemble_flood_layered | 0.04183333 | 7.011 | [0.003563, 0.006230] |
| ensemble_flood_sumproduct | 0.04229167 | 46.506 | [0.002708, 0.006042] |
| global_plus_local96 | 0.04485417 | 7.665 | [0.000917, 0.002833] |
| physical_cost_301 | 0.04218750 | 5.273 | [0.002749, 0.006375] |
| ensemble_physical_cost_274 | 0.03914583 | 10.128 | [0.005437, 0.009584] |
| diverse_logical_generators_411 | 0.03731250 | 13.767 | [0.007458, 0.011334] |
| selective_ensemble_158 | 0.04206250 | 5.356 | [0.003249, 0.006042] |
| class_neighborhood_8 | 0.03683333 | 23.810 | [0.007875, 0.011792] |
| class_neighborhood_12 | 0.03666667 | 27.588 | [0.008082, 0.011958] |
| selective_diverse_411 | 0.03739583 | 10.091 | [0.007375, 0.011271] |
| failures_only_diverse_411 | 0.03802083 | 8.009 | [0.006894, 0.010605] |
| failures_only_class_neighborhood_8 | 0.03756250 | 12.141 | [0.007311, 0.011021] |
| layered_only_diverse_137 | 0.04154167 | 4.189 | [0.003104, 0.007230] |
| failures_only_dual_274_short | 0.03981250 | 4.797 | [0.005104, 0.008855] |
| disjoint_subspace_mass | 0.03706250 | 21.375 | [0.007625, 0.011542] |
| failures_only_disjoint_mass | 0.03791667 | 11.709 | [0.006958, 0.010646] |
| learned_correction_pilot | 0.03804167 | 8.671 | [0.006770, 0.010543] |

The local-region method grows syndrome-connected detector regions by reliability, accepts a correction only when the local span solves the syndrome, and merges with the global proposal. About 77% of pilot shots admit its bounded local solution. It improves the reference modestly but does not beat the stronger schedule ensemble; it is a custom bounded region experiment, not a claim to reproduce a published full LSD implementation.

Sum-product was numerically stable but much slower (46.5 seconds for 12,000 shots) without beating layered min-sum. The 64x64 residual MLP pilot used only 40,000 newly simulated training/tuning shots (16,000 train and 4,000 tuning per basis), original random initialization and 16 epochs. X selected epoch 1 and Z selected the untrained epoch-0 residual. Its development LER 0.03804167 did not improve its physics parent 0.03802083; it is rejected, and its weights/logs are preserved. No neural model is in either new finalist.

## Frozen architectures and measured runtime

Accuracy: three independent deterministic min-sum BP schedules (flooding, layered, alternating-direction layered), physical-likelihood generator selection with logical diversity, exact deduplication, marginal decisions, and bounded class-preserving zero-logical neighborhoods. Twelve neighborhood generators per class are explored through order two; this is a targeted mass approximation, not a complete class partition function.

Efficiency: retain the first syndrome-consistent original BP result; for BP failures only, combine the original flooding proposal with a 15-iteration layered proposal, a 16-generator bounded list per proposal, physical-likelihood/logical-diversity selection and deduplicated bit marginals. Config files contain every numerical parameter.

| Decoder | Actual 200k workload seconds, every run | Median | Provisional local score (15.4, .2) | Legacy proxy (3, .1) |
|---|---|---:|---:|---:|
| hybrid | 35.742, 65.213, 63.851 | 63.851 | 0.06405843 | 0.06544125 |
| efficient_finalist | 107.773, 124.214, 109.487 | 109.487 | 0.05741034 | 0.05557070 |

Best local median proxy role: **efficient_finalist**, retained separately from best accuracy. These are local interleaved measurements with three repeats, not the organizer's five-repeat B200 evaluation. The accuracy model was measured on 40,000 confirmation shots only; multiplying its time by five gives a **projection** of 558.7 seconds for 200,000, above the public 300-second limit locally. That projection is not an actual full-workload measurement or an official disqualification. Do not deploy the accuracy model unchanged without resolving runtime.

Timing drift is substantial: the unchanged hybrid reference ranges from about 36 to 65 seconds within this experiment. The cause is not established. Local median proxy ranking is therefore tentative; retain the successful submission and repeat an isolated, controlled benchmark on the intended environment before relying on a score advantage. These runs do not show a kernel speed improvement over Milestone 5.

All timings use the same local Windows CPU, 12 Numba threads; hybrid uses four Torch threads. Compilation/import is excluded and separately logged. Memory values are sampled entire-process RSS, including multiple loaded finalists, Torch for the reference, JIT code and data; they are not isolated per-model allocations or GPU memory. The full-workload source is the preserved Milestone 5 native simulator detector array; its labels are never loaded for these timings. No Kaggle test rows or IDs are used for development or timing.

The latest public README was rechecked and saved. It states bitwise MAE, permitted general-purpose libraries, a 15.4/.2 score and 300-second hard limit, but retains an older 3/.1 section and single/two-file text. Private Kaggle rules still take precedence. Exact official Python/CUDA image is not available. No B200 performance or leaderboard rank is claimed. Source: https://github.com/JuliusRye/QEC_Decoder_Hakathon_2026 .

## Promotion, preservation and next step

Both new finalists pass the fresh paired accuracy-improvement criterion. The best-accuracy and best-local-score artifacts are preserved separately; the original successful submission is always retained. Reaching the public top 2 is not established by these simulations. The remaining relative reduction needed from the accuracy model to 0.03387 is 5.69%. Its entire absolute simulation interval is reported above rather than extrapolating a leaderboard score.

Recommended next experiment: exact, bounded marginalization of overlapping zero-logical cycles within each ambiguous logical class. The present order-two neighborhood omits higher-order combinations; the disjoint-subspace control captures all orders only when supports do not overlap. Start with six/eight generators (64/256 combinations per class), enumerate with Gray-code updates, measure added distinct probability mass and correct-bit changes, and gate expensive work by posterior ambiguity. Compare on development only, then freeze and generate another new confirmation set. This targets the remaining probability-ranking gap; further raw syndrome MLP training or blindly increasing a global list is not supported by this phase.

Do not recommend a new top-2 submission yet. First establish below-target accuracy and a feasible actual runtime, or explicitly choose a leaderboard accuracy experiment knowing the code-hand-in risk. No final Kaggle CSV was generated in this phase.

Eight advanced tests and all 42 existing tests passed. Both new frozen distributions passed relocated fresh-process checks with network, original-project imports and Torch imports blocked; their outputs matched confirmation prefixes, including row permutations, logical order, empty/single batches and invalid-input rejection. Preservation hashes cover all 354 non-cache Milestone 1–5 files. Native main datasets total 92,000 new shots (12k development, 40k own training/tuning, 40k confirmation), plus tiny unit fixtures; no million-shot generation or expensive parameter sweep.

An initial Numba hash-index type inference error was corrected before any new-model pilot results. A pilot-resume bug overwrote a derived failure-summary JSON; it was reconstructed exactly from the untouched saved detector, label, prediction and per-shot diagnostic arrays, and the resume guard was fixed. No samples, predictions, configurations or frozen runtime source changed in that repair. Subsequent experiments retain source snapshots and predeclared configurations. The legacy suite emits its known warning for a rejected historical cache-reuse kernel, which is absent from both new runtime packages. No banned decoder code/library, external pretrained weight, hidden label or test-ID memorization is involved. All decoding additions are this project's own source; the allowed organizer DEM helper retains its license.

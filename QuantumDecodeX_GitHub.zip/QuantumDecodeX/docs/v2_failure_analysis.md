# V2 reproduction and failure analysis

Actual submission_v2 decoder: class_neighborhood_12. Full 40,000-shot regression reproduction: LER 0.03591250, every prediction exactly matches the preserved file. The user reports Kaggle v2 score 0.03703; this is context, not fitting data.

| Basis/group | Shots | Wrong bits | Conditional LER | Share of wrong bits |
|---|---:|---:|---:|---:|
| X/first_BP_consistent | 14623 | 592 | 0.01012104219380428 | 20.225% |
| X/first_BP_failed | 5377 | 2335 | 0.10856425516087037 | 79.775% |
| X/any_BP_proposal_consistent | 15419 | 949 | 0.015386860367079577 | 32.422% |
| X/no_BP_proposal_consistent | 4581 | 1978 | 0.10794586334861384 | 67.578% |
| X/true_class_present | 20000 | 2927 | 0.0365875 | 100.000% |
| X/true_class_absent | 0 | 0 | None | 0.000% |
| X/syndrome_weight_0_0 | 876 | 0 | 0.0 | 0.000% |
| X/syndrome_weight_1_4 | 4594 | 135 | 0.007346538963865912 | 4.612% |
| X/syndrome_weight_5_8 | 7001 | 641 | 0.02288958720182831 | 21.900% |
| X/syndrome_weight_9_12 | 4963 | 1049 | 0.05284102357445094 | 35.839% |
| X/syndrome_weight_13_20 | 2497 | 1050 | 0.10512615138165798 | 35.873% |
| X/syndrome_weight_21_70 | 69 | 52 | 0.18840579710144928 | 1.777% |
| X/active_time_slices_1 | 1738 | 78 | 0.011219792865362486 | 2.665% |
| X/active_time_slices_2 | 4065 | 301 | 0.018511685116851168 | 10.284% |
| X/active_time_slices_3 | 5144 | 736 | 0.03576982892690513 | 25.145% |
| X/active_time_slices_4 | 4915 | 954 | 0.048524923702950154 | 32.593% |
| X/active_time_slices_5 | 2678 | 684 | 0.0638536221060493 | 23.369% |
| X/active_time_slices_6 | 584 | 174 | 0.07448630136986302 | 5.945% |
| Z/first_BP_consistent | 14928 | 603 | 0.010098472668810289 | 21.391% |
| Z/first_BP_failed | 5072 | 2216 | 0.10922712933753943 | 78.609% |
| Z/any_BP_proposal_consistent | 15680 | 933 | 0.01487563775510204 | 33.097% |
| Z/no_BP_proposal_consistent | 4320 | 1886 | 0.10914351851851851 | 66.903% |
| Z/true_class_present | 20000 | 2819 | 0.0352375 | 100.000% |
| Z/true_class_absent | 0 | 0 | None | 0.000% |
| Z/syndrome_weight_0_0 | 903 | 0 | 0.0 | 0.000% |
| Z/syndrome_weight_1_4 | 4653 | 108 | 0.005802707930367505 | 3.831% |
| Z/syndrome_weight_5_8 | 7015 | 674 | 0.024019957234497506 | 23.909% |
| Z/syndrome_weight_9_12 | 4939 | 925 | 0.04682121887021664 | 32.813% |
| Z/syndrome_weight_13_20 | 2421 | 1035 | 0.10687732342007435 | 36.715% |
| Z/syndrome_weight_21_70 | 69 | 77 | 0.27898550724637683 | 2.731% |
| Z/active_time_slices_1 | 1754 | 55 | 0.007839224629418473 | 1.951% |
| Z/active_time_slices_2 | 4169 | 327 | 0.01960901894938834 | 11.600% |
| Z/active_time_slices_3 | 5132 | 645 | 0.03142049883086516 | 22.880% |
| Z/active_time_slices_4 | 4868 | 899 | 0.04616885784716516 | 31.891% |
| Z/active_time_slices_5 | 2595 | 653 | 0.06290944123314066 | 23.164% |
| Z/active_time_slices_6 | 579 | 240 | 0.10362694300518134 | 8.514% |

High-confidence errors, coverage, all logical-bit metrics and temporal groups are in the JSON files. Categories overlap. Incorrect rankings with the true class present do not prove that every such error is recoverable: intrinsic ambiguity and omitted within-class probability mass remain indistinguishable without an improved posterior oracle.

Both circuits produce an undecomposed DEM with approximate_disjoint_errors=False. Thus we are not intentionally discarding disjoint-noise correlations during extraction. Native/DEM marginal checks are diagnostic only. There is currently no evidence that model mismatch is the dominant limitation; approximate posterior estimation is the actionable hypothesis, not an established information-theoretic conclusion.

Selected next hypothesis after this audit: sum higher-order, overlapping zero-logical cycle configurations within each represented class, with exact deduplication against the existing pool. Use a custom Walsh transform of physical-energy parity coefficients to evaluate all selected-cycle states efficiently. Start with bounded 8/10/12-cycle pilots; retain v2 as the control. This is exact only inside the selected subspace, not the complete physical posterior.

No neural training or expensive sweep is selected yet. CUDA is unavailable on the local machine; all work remains on the existing CPU. The earlier 40k-shot residual pilot was negative; a larger learned experiment requires a concrete feature/architecture hypothesis and learning-curve budget.

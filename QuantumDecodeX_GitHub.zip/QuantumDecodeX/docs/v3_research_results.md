# V3 research execution report

**No new decoder has a supported improvement over v2 in this phase. V2 remains the selected decoder, and submission_v3.csv was not generated.** This avoids a false promotion; it does not achieve the mission's stretch target.

## Reproduction and diagnosis

The exact code used for submission_v2.csv reproduced all 40,000 stored predictions, with X LER 0.03658750, Z LER 0.03523750, combined 0.03591250. Measured CPU time was 177.068 seconds; sampled process peak RSS 262.49 MiB. The user reports Kaggle v2 score 0.03703; no new public score is inferred.

The true logical class is represented on every one of these shots, including every erroneous prediction. There are 5,746 wrong logical bits: 4,551 after initial BP failure (79.20%) and 1,195 after initial parity-consistent BP (20.80%). At least 99% approximate marginal confidence accompanies 984 wrong bits (17.12%). This localizes the actionable issue to probability ranking/mass and possibly intrinsic ambiguity; it does not prove that every wrong decision is recoverable.

The detailed failure report contains actual syndrome-weight and temporal group frequencies. Both supplied DEMs extract with approximate_disjoint_errors=False, H rank 70 and augmented [H;L] rank 74. All 2,470 X / 2,465 Z syndrome columns are unique. Native-versus-DEM marginal checks on 100k shots per source/basis have maximum standardized differences around 2.16. There is no observed evidence of gross noise-model mismatch, but marginal checks alone cannot prove the complete joint distribution.

## Implemented algorithms and measured comparison

The main physics addition computes a logical-class partition sum over selected overlapping zero-logical cycles. Physical error energy is a sum of parity characters in cycle-selection bits. An independently written Walsh transform evaluates all selected states, and a free-coordinate membership test unions their mass with the original deduplicated pool without counting shared configurations twice. This is exact within the chosen subspace, not exact global decoding.

The new learning pilot compares a compact 64x64 four-sigmoid residual against a 64x64 16-class softmax posterior with logical marginalization. Both use the same v2 features, native data and fixed split. 100,000 shots per basis were generated: 80k training / 20k development. Feature extraction is checkpointed in 5k blocks; raw binary native data, hashes, all weights and histories are preserved. Epochs were selected using development only. One fixed 50/50 marginal mixture was declared before training results, with no weight tuning.

| Decoder | Dataset | X LER | Z LER | Combined LER | Full decode seconds | Paired improvement CI |
|---|---|---:|---:|---:|---:|---|
| v2 | fresh_physics_selection_8000 | 0.03675000 | 0.03787500 | 0.03731250 | 21.925 | reference |
| v2_plus_exact8 | fresh_physics_selection_8000 | 0.03675000 | 0.03781250 | 0.03728125 | 32.241 | [-0.0001875, 0.00028125] |
| exact10_union_base | fresh_physics_selection_8000 | 0.03706250 | 0.03806250 | 0.03756250 | 18.614 | [-0.00053125, 0.0] |
| exact12_union_base | fresh_physics_selection_8000 | 0.03668750 | 0.03800000 | 0.03734375 | 20.504 | [-0.0001875, 6.25e-05] |
| learned_sigmoid4 | fresh_physics_selection_8000 | 0.03675000 | 0.03787500 | 0.03731250 | 22.322 | [-0.000375, 0.000375] |
| learned_class16 | fresh_physics_selection_8000 | 0.03643750 | 0.03787500 | 0.03715625 | 22.425 | [-0.00034375, 0.0006875] |
| learned_fixed_half_mixture | fresh_physics_selection_8000 | 0.03668750 | 0.03787500 | 0.03728125 | not measured; cached | [-0.000375, 0.00040625] |
| v2 | old_regression_40000 | 0.03658750 | 0.03523750 | 0.03591250 | 177.068 | reference |
| learned_sigmoid4 | old_regression_40000 | 0.03661250 | 0.03523750 | 0.03592500 | not measured; cached | [-0.00015625, 0.0001375] |
| learned_class16 | old_regression_40000 | 0.03671250 | 0.03523750 | 0.03597500 | not measured; cached | [-0.00024375, 0.00011890625000000056] |
| learned_fixed_half_mixture | old_regression_40000 | 0.03658750 | 0.03523750 | 0.03591250 | not measured; cached | [-0.00015, 0.0001625] |

The 8,000-shot selection set was new native data, independent of neural training/development. The 40,000-shot regression set is the old confirmation set used for failure diagnosis, so it is explicitly not described as a new sealed confirmation. Whole-shot, basis-stratified paired intervals include correlations among the four bits. Per-logical-bit LER, corrected/introduced errors, source snapshots, runtime and process RSS are in the underlying JSON/NPZ results. Development/model-selection point estimates alone are not promotion evidence.

## Negative results and implications

V2 plus exact 8-cycle mass corrected three bits and introduced two on selection: net one bit, with a paired interval spanning zero. Full 10/12-cycle subspace controls did not improve. The represented-state and probability-change diagnostics are retained; simply enumerating more combinations inside these particular small cycle sets is not supported as a route to a large gain.

For both neural heads X selected epoch 1 and Z selected epoch 0. Later epochs generally worsened development LER despite more optimization. The 16-class head improved the small selection point estimate but was worse on the larger regression set (0.035975 vs v2 0.0359125). The sigmoid head was 0.035925; the fixed mixture matched v2's aggregate regression LER. All paired intervals include no improvement. These curves do not justify 1–2M or 5M training, ensembles fitted to the leaderboard, or replacing v2.

A restricted-event Bayes-risk lower bound, enumerating all DEM error vectors of weight <=2, is 0.00102307 combined. It is rigorous for the extracted independent DEM but far too weak to determine whether 0.020 is feasible. It is not an estimated optimal LER, not an attainable decoder and not evidence that 0.020 can be reached. The omitted higher-weight mass is substantial. No result here meets even the intermediate 0.035 target reliably.

## Resources, integrity and next step

No CUDA GPU was available. All work used the existing local CPU and permitted general-purpose libraries; no paid compute, pretrained competitor model, prohibited decoder implementation, hidden label or test-ID fitting was used. No Kaggle test predictions were regenerated in this phase. The retained v2 real test runtime remains the previously measured 592.297 seconds; that is local batched CPU timing, not B200 timing. Public CSV accuracy and executable speed-adjusted scores remain separate.

All 56 tests passed ({'new': 6, 'original': 42, 'advanced': 8}). All 549 protected previous files match their pre-phase hashes, including both submission CSVs. New helpers were tested against complete small-case enumeration, including overlapping cycles, mass-union deduplication, numerical extremes, learned logical-bit ordering and the ambiguity-bound monotonicity. The old suite's known experimental Numba cache warning is retained in its log; it does not affect the selected v2 model.

The full research mission is not complete. The next highest-value experiment is importance-weighted logical-posterior estimation over all nonpivot variables, rather than only the current 12-generator neighborhoods. Use a BP-informed proposal with nonzero support, solve pivots exactly in GF(2), and weight by target/proposal likelihood. First measure effective sample size and estimator variance; duplicated Monte Carlo samples have legitimate multiplicities and must not be incorrectly deduplicated as deterministic-list entries. A bounded 64/256-sample pilot on 1k shots/basis can decide whether to expand. If weights collapse, stop rather than report spurious confidence. This method is not implemented or claimed tested yet.

Best-first searches, class-conditioned factor-graph/free-energy approximations, and structured graph/unfolded neural BP remain explicit unfinished alternatives. A full factor-graph training run is substantially more expensive on the available CPU; choose it only after a small learning-curve or posterior-variance feasibility test. Larger raw MLP training is not the recommended next action.

Freeze any future candidate before generating a new sealed set. Require positive paired generalization evidence before v3. Do not reuse the old regression set as the seal, and never copy v2 predictions into a file labelled as an improved v3. CONTINUATION_STATE.json contains exact completed/pending work and reproduction commands.

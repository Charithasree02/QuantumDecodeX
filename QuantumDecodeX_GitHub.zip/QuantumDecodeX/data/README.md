Place your original competition test.csv or train.csv here for local use.
This directory's inputs are ignored by Git. Circuit assets needed by inference
are already included under each decoder folder's assets/ directory.

# QuantumDecodeX

Physics-based quantum error correction decoding for the QEC Decoder Hackathon
2026: custom belief propagation, GF(2) candidate search, logical-class posterior
aggregation, and an optional self-trained hybrid neural gate.

This repository contains the complete runnable code for four validated models,
including the best accuracy decoder used for `submission_v2.csv`. Each implements:

```python
decode(circuit: stim.Circuit, detector_events: np.ndarray) -> np.ndarray
```

Input: binary detector events `(shots, 70)`. Output: binary `uint8` logical flips
`(shots, 4)` in **L0, L1, L2, L3** order. X/Z circuits, frozen configurations and
all required inference assets are included. Only the hybrid uses neural weights;
those weights were trained by this project, not downloaded from another team.

## Which decoder should I use?

| Folder under `decoders/` | Role | Independent combined LER | Historical local time / 40k shots |
|---|---|---:|---:|
| **`accuracy_v2`** | **Best validated accuracy; used for submission v2** | **0.03591250** | 111.75 s |
| `efficient_physics` | Newer efficient physics alternative; best provisional local score | 0.03878125 | 21.37 s |
| `fast_hybrid_v1` | Earlier fast hybrid submission/fallback | 0.04820000 | 7.20 s |
| `pure_physics_v1` | Earlier pure physics fallback | 0.04820000 | 7.55 s |

These results use **the same 40,000 native Stim confirmation shots**, 20,000 per
basis, with every logical bit scored. Timings are historical local Windows CPU
measurements after import/JIT, not official B200 results. They vary with workload
and machine conditions. Memory and paired intervals are in `docs/benchmarks.json`.
The accuracy model separately took **592.30 seconds** on the actual 200k-row
competition test workload locally. Its executable hand-in runtime needs work.

The user-reported Kaggle CSV scores were **v1: 0.04833**, **v2: 0.03703**.
Simulator LER is not a promised Kaggle score. Later overlapping-cycle and neural
research did not establish an improvement over v2; the 0.020 target was not met.
The efficient model's speed-adjusted ranking is provisional because timing drift
was substantial. Preserve the earlier fast models when assessing deployment.

## Install

Clone the repository first:

```bash
git clone https://github.com/Charithasree02/QuantumDecodeX.git
cd QuantumDecodeX
```

Tested environment: CPython **3.11.5**, NumPy 2.2.4, Stim 1.16.0, Numba 0.61.2,
llvmlite 0.44.0. A GPU is not required. From this repository root:

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
```

For `fast_hybrid_v1`, also install the pinned CPU PyTorch build:

```bash
python -m pip install -r requirements-hybrid.txt --extra-index-url https://download.pytorch.org/whl/cpu
```

All other decoders run without PyTorch. No compiler binary/cache or virtual
environment is shipped. Kernels compile at import. Official Python/CUDA/hardware
compatibility has not been established; revalidate on the actual target.

## Generate a submission CSV locally

Place your original competition `test.csv` in `data/`. It must contain `id`,
`basis`, and `D0` through `D69`; detector columns are mapped by their names.

```bash
python scripts/predict_csv.py --decoder accuracy_v2 --test data/test.csv --out results/submission.csv
```

The script preserves every input ID and its original order, including interleaved
X/Z rows, validates binary predictions and writes `id,L0,L1,L2,L3`. A sibling
`submission.validation.json` records the row count, SHA-256, input/config hashes
and decode timing. Existing outputs are never overwritten. **Nothing is uploaded.**
The slow accuracy model can take several minutes for 200,000 rows on a local CPU.

Select another decoder explicitly with `--decoder efficient_physics`,
`--decoder fast_hybrid_v1`, or `--decoder pure_physics_v1`.

## Evaluate on independent simulations

```bash
python scripts/evaluate.py --decoder accuracy_v2 --shots-per-basis 1000 --runs 1 --out results/evaluation.json
```

The exact supplied circuit/noise model generates both detectors and labels.
The report gives X/Z, combined and per-logical-bit LER. To reproduce the historical
confirmation sample generation, use **Stim 1.16.0** and:

```bash
python scripts/evaluate.py --decoder accuracy_v2 --shots-per-basis 20000 --seed-x 2026116401 --seed-z 2026116402 --out results/confirmation.json
```

A supplied native-simulation NPZ can instead be evaluated with `--dataset FILE`;
its keys must be `X_detectors`, `X_labels`, `Z_detectors`, `Z_labels`.
Evaluate all shots, including nonconverged BP cases. The metric is incorrect
logical bits divided by total logical bits, not the fraction of erroneous shots.

## Use the interface directly

```python
import sys
sys.path.insert(0, 'scripts')
from qec_tools import load_decoder, load_circuits
import numpy as np

decoder = load_decoder('accuracy_v2')
circuit = load_circuits('accuracy_v2')['X']
predictions = decoder.decode(circuit, np.zeros((10, 70), dtype=bool))
assert predictions.shape == (10, 4)
```

Each decoder folder is independently usable: put that folder on sys.path and
import its `decoder.py`. Asset paths resolve from the module, not your working
directory. Use the helper above when loading multiple models in one process.
Unknown circuit fingerprints and invalid detector arrays are rejected.

## Tests

```bash
python -B -m unittest discover -s tests -v
```

Tests compare every included decoder to fixed **own-simulation** predictions,
check logical-bit order, X/Z behavior, empty/single batches, repeatability, row
permutations, source hashes, interleaved CSV output and refusal to overwrite.
The hybrid check is included when PyTorch is installed. No competition test rows,
IDs, hidden labels or saved competition predictions are used by tests/inference.

## Architecture and reproducibility

`accuracy_v2` combines three deterministic min-sum BP schedules, reliability-
guided GF(2) elimination, original-physical-likelihood generator ranking,
logical-class diversity, exact physical-candidate deduplication, bitwise marginal
decisions and bounded class-preserving error neighborhoods. `efficient_physics`
uses a shorter two-proposal search only after initial BP failure. Exact parameter
values are in each model's `config.json`.

The earlier pure model uses the 79-candidate bounded search. The earlier hybrid
adds our basis-specific small MLP gate and includes both checkpoint files.
See [hybrid weight reproduction](docs/TRAINING.md) for the original recipe.

The inference files and weights are byte-identical to the validated originals;
`docs/SOURCE_PROVENANCE.json` records their SHA-256 hashes. Packaging changes only
documentation, manifests, portable tools, and the training script's input-path
argument. Test fixture predictions are held separately under tests/ and are
never read by a decoder. `docs/` includes the measured reports and failed research
results so that an attractive algorithm is not mistaken for a validated gain.

## Reproducibility and project status

The best independently validated accuracy remains **0.03591250 simulated LER**.
The reported v2 Kaggle CSV score is **0.03703**. Later research did not establish
a better decoder; no improved v3 submission is claimed. The original and newer
fast alternatives remain available rather than hiding runtime/accuracy tradeoffs.

Four repository tests cover all four models in the pinned environment, including
the optional hybrid, frozen simulation predictions, input/output checks and an
interleaved X/Z CSV round trip. Hybrid training replay also reproduced every
original checkpoint tensor. Evidence is in `docs/verification/`.

```bash
python scripts/verify_integrity.py
```

The file manifest and `.gitattributes` preserve byte-level provenance across Git
checkouts. Competition data, generated submissions, environments and caches stay
local under ignored directories. Included fixture data is our own simulation
data and is never used at inference. Source/license notices are in LICENSE and
NOTICE.md. The dependency/hardware requirements in private competition rules
remain authoritative for a competition hand-in.

"""Portable helpers for our frozen decoders; no workspace dependency."""
from pathlib import Path
import csv,hashlib,importlib.util,sys,time
import numpy as np
import stim

ROOT=Path(__file__).resolve().parents[1]
DECODERS=('accuracy_v2','efficient_physics','fast_hybrid_v1','pure_physics_v1')
_MODELS={}

def sha256(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_decoder(name):
    if name not in DECODERS:raise ValueError('Unknown decoder: '+str(name))
    if name not in _MODELS:
        path=ROOT/'decoders'/name/'decoder.py'
        spec=importlib.util.spec_from_file_location('export_'+name,path)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        _MODELS[name]=module
    return _MODELS[name]

def load_circuits(name):
    return {b:stim.Circuit.from_file(ROOT/'decoders'/name/'assets'/f'{b}_circuit.stim') for b in 'XZ'}

def checked_predictions(value,shots):
    a=np.asarray(value)
    if a.shape!=(shots,4) or a.dtype.kind not in 'buif' or not np.isfinite(a).all() or not np.isin(a,[0,1]).all():
        raise ValueError('Expected finite binary (shots,4) logical predictions')
    return a.astype(np.uint8,copy=False)

def read_test_csv(path):
    detectors=[f'D{i}' for i in range(70)];required=['id','basis']+detectors
    ids=[];bases=[];rows=[]
    with Path(path).open(newline='',encoding='utf-8-sig') as f:
        reader=csv.reader(f)
        try:header=next(reader)
        except StopIteration:raise ValueError('CSV is empty')
        if len(header)!=len(required) or set(header)!=set(required):raise ValueError('Expected id,basis,D0..D69 with no label columns')
        index={key:header.index(key) for key in required}
        for row in reader:
            if len(row)!=len(header):raise ValueError('Ragged CSV row')
            shot_id=row[index['id']];basis=row[index['basis']];values=[row[index[d]] for d in detectors]
            if not shot_id or basis not in ('X','Z') or any(v not in ('0','1') for v in values):raise ValueError('Missing ID, unsupported basis or nonbinary detectors')
            ids.append(shot_id);bases.append(basis);rows.append(values)
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate IDs')
    return ids,np.asarray(bases,dtype='U1'),np.asarray(rows,dtype=np.uint8).reshape(-1,70)

def predict_in_original_order(module,circuits,events,bases,batch_size=5000):
    if batch_size<1:raise ValueError('Batch size must be positive')
    if events.shape!=(len(bases),70) or not np.isin(bases,['X','Z']).all():raise ValueError('Invalid event/basis dimensions')
    out=np.empty((len(events),4),np.uint8);seconds={}
    for b in 'XZ':
        rows=np.flatnonzero(bases==b);start=time.perf_counter()
        for offset in range(0,len(rows),batch_size):
            selection=rows[offset:offset+batch_size]
            out[selection]=checked_predictions(module.decode(circuits[b],events[selection]),len(selection))
        seconds[b]=time.perf_counter()-start
    return out,seconds

def validate_submission(path,expected_ids):
    with Path(path).open(newline='',encoding='utf-8-sig') as f:
        reader=csv.reader(f)
        if next(reader,None)!=['id','L0','L1','L2','L3']:raise ValueError('Incorrect submission header/order')
        rows=list(reader)
    if len(rows)!=len(expected_ids) or [row[0] if row else None for row in rows]!=list(expected_ids):raise ValueError('IDs or row order differ from input')
    if any(len(row)!=5 or any(v not in ('0','1') for v in row[1:]) for row in rows):raise ValueError('Missing or nonbinary predictions')
    return {'rows':len(rows),'exact_id_order':True,'binary_no_missing':True,'sha256':sha256(path)}

def bitwise_metrics(prediction,labels):
    labels=checked_predictions(labels,len(labels));prediction=checked_predictions(prediction,len(labels));wrong=prediction!=labels
    return {'shots':len(labels),'wrong_bits':int(wrong.sum()),'ler':float(wrong.mean()) if len(labels) else None,
        'per_logical_ler':wrong.mean(0).tolist() if len(labels) else [None]*4}

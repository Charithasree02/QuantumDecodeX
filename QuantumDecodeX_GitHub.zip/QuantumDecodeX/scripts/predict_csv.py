"""Generate and validate a local prediction CSV. Never uploads anything."""
from pathlib import Path
import argparse,csv,json,time
from qec_tools import *

def run(decoder,test,out,batch_size=5000):
    out=Path(out);temporary=out.with_suffix(out.suffix+'.tmp')
    if out.exists() or temporary.exists():raise FileExistsError('Output already exists; choose a new filename')
    ids,bases,events=read_test_csv(test)
    start=time.perf_counter();module=load_decoder(decoder);initialization=time.perf_counter()-start
    pred,times=predict_in_original_order(module,load_circuits(decoder),events,bases,batch_size)
    out.parent.mkdir(parents=True,exist_ok=True)
    with temporary.open('x',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['id','L0','L1','L2','L3'])
        for shot_id,row in zip(ids,pred):writer.writerow([shot_id,*map(int,row)])
    report=validate_submission(temporary,ids);temporary.replace(out)
    report.update({'decoder':decoder,'input_sha256':sha256(test),'decoder_config_sha256':sha256(ROOT/'decoders'/decoder/'config.json'),
        'initialization_seconds':initialization,'per_basis_seconds':times,'total_decode_seconds':sum(times.values()),
        'logical_bit_order':['L0','L1','L2','L3'],'batch_size':batch_size,'uploaded':False})
    out.with_suffix('.validation.json').write_text(json.dumps(report,indent=2))
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--decoder',choices=DECODERS,default='accuracy_v2');p.add_argument('--test',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--batch-size',type=int,default=5000)
    a=p.parse_args();print(json.dumps(run(a.decoder,a.test,a.out,a.batch_size),indent=2))

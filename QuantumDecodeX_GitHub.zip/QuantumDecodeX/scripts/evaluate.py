"""Evaluate on own Stim simulations or a supplied labeled simulation NPZ."""
from pathlib import Path
import argparse,json,time
from qec_tools import *

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--decoder',choices=DECODERS,default='accuracy_v2');p.add_argument('--shots-per-basis',type=int,default=1000);p.add_argument('--seed-x',type=int,default=2026111601);p.add_argument('--seed-z',type=int,default=2026111602);p.add_argument('--dataset',type=Path);p.add_argument('--runs',type=int,default=1);p.add_argument('--out',type=Path)
    a=p.parse_args()
    if a.runs<1 or a.shots_per_basis<1:raise ValueError('Shots/runs must be positive')
    if a.out and a.out.exists():raise FileExistsError('Evaluation output already exists')
    start=time.perf_counter();module=load_decoder(a.decoder);initialization=time.perf_counter()-start;circuits=load_circuits(a.decoder)
    events={};labels={}
    if a.dataset:
        with np.load(a.dataset) as z:
            for b in 'XZ':events[b]=z[b+'_detectors'];labels[b]=z[b+'_labels']
    else:
        for b,seed in [('X',a.seed_x),('Z',a.seed_z)]:events[b],labels[b]=circuits[b].compile_detector_sampler(seed=seed).sample(a.shots_per_basis,separate_observables=True)
    times=[];first=None
    for _ in range(a.runs):
        start=time.perf_counter();pred={b:checked_predictions(module.decode(circuits[b],events[b]),len(events[b])) for b in 'XZ'};times.append(time.perf_counter()-start)
        if first is None:first=pred
        elif not all(np.array_equal(first[b],pred[b]) for b in 'XZ'):raise AssertionError('Inference differs across runs')
    metrics={b:bitwise_metrics(first[b],labels[b]) for b in 'XZ'};metrics['combined']=bitwise_metrics(np.concatenate([first[b] for b in 'XZ']),np.concatenate([labels[b] for b in 'XZ']))
    result={'decoder':a.decoder,'dataset':'supplied simulation NPZ' if a.dataset else 'fresh native Stim simulations','seeds':None if a.dataset else {'X':a.seed_x,'Z':a.seed_z},'metrics':metrics,'run_seconds':times,'median_seconds':float(np.median(times)),'initialization_seconds':initialization,'scope':'local CPU; no official-hardware claim; import excluded'}
    if a.out:a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()

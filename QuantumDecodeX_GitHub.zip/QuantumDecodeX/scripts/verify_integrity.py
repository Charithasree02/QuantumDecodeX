"""Check the exported file hashes without importing a decoder."""
from pathlib import Path
import hashlib,json

ROOT=Path(__file__).resolve().parents[1]
def main():
    manifest=json.loads((ROOT/'FILE_MANIFEST.json').read_text());failures=[]
    for item in manifest['files']:
        path=(ROOT/item['path']).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:failures.append(item['path'])
    if failures:raise SystemExit('Integrity check failed: '+', '.join(failures))
    print(f"Verified {len(manifest['files'])} files")
if __name__=='__main__':main()

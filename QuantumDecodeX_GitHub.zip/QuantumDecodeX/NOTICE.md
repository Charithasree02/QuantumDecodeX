# Source notices

The BP, GF(2) search, posterior/candidate aggregation, MLP and hybrid algorithms
were developed for this project. No prohibited existing QEC decoder library,
copied competitor implementation, competitor/private source or external
pretrained decoder weight is included.

The supplied circuit assets and `dem.py` extraction helper originate from the
organizer starter repository, University of Copenhagen. Its MIT license is
preserved verbatim in LICENSE and the decoder folders. The helper extracts a DEM;
it is not a third-party decoder implementation. No tutorial notebooks are bundled.

Organizer source: https://github.com/JuliusRye/QEC_Decoder_Hakathon_2026 .
Public rules allow general-purpose NumPy/Numba/Stim/PyTorch and own decoders;
private competition rules remain authoritative for any competition hand-in.

Reported public scores were provided by the participant. Local simulator LER,
timings and provisional speed-adjusted scores are explicitly distinguished from
official hardware/private leaderboard measurements throughout the documentation.

from pathlib import Path
import sys,unittest,tempfile,csv,json,hashlib,importlib.util
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from qec_tools import *
from predict_csv import run

class RepositoryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture=np.load(ROOT/'tests/fixtures/interface_regression.npz')

    def test_frozen_source_identity(self):
        provenance=json.loads((ROOT/'docs/SOURCE_PROVENANCE.json').read_text())
        for name,item in provenance.items():
            for relative,digest in item['unchanged_inference_file_sha256'].items():
                self.assertEqual(sha256(ROOT/'decoders'/name/relative),digest)

    def test_all_decoder_interfaces_and_frozen_predictions(self):
        for name in DECODERS:
            if name=='fast_hybrid_v1' and importlib.util.find_spec('torch') is None:continue
            with self.subTest(decoder=name):
                model=load_decoder(name);circuits=load_circuits(name)
                for b in 'XZ':
                    x=self.fixture[b+'_detectors'];expected=self.fixture[name+'_'+b+'_predictions'];actual=checked_predictions(model.decode(circuits[b],x),len(x))
                    np.testing.assert_array_equal(actual,expected)
                    order=np.random.default_rng(16).permutation(len(x));np.testing.assert_array_equal(model.decode(circuits[b],x[order]),expected[order])
                    self.assertEqual(model.decode(circuits[b],x[:0]).shape,(0,4));np.testing.assert_array_equal(model.decode(circuits[b],x[:1]),expected[:1])
                    other=circuits[b].copy();other.append('TICK')
                    with self.assertRaises(ValueError):model.decode(other,x[:1])

    def test_interleaved_csv_roundtrip_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'test.csv';out=Path(tmp)/'submission.csv';ids=[];expected=[]
            with source.open('w',newline='') as f:
                w=csv.writer(f);w.writerow(['id','basis']+[f'D{i}' for i in range(70)])
                for i in range(8):
                    for b in 'ZX':
                        ids.append(f'fixture_{b}_{i}');w.writerow([ids[-1],b,*self.fixture[b+'_detectors'][i].astype(int)])
                        expected.append(self.fixture['accuracy_v2_'+b+'_predictions'][i])
            result=run('accuracy_v2',source,out,batch_size=3);self.assertEqual(result['rows'],16);self.assertFalse(result['uploaded'])
            with out.open(newline='') as f:reader=csv.reader(f);next(reader);rows=list(reader)
            self.assertEqual([r[0] for r in rows],ids);np.testing.assert_array_equal(np.array([r[1:] for r in rows],np.uint8),expected)
            with self.assertRaises(FileExistsError):run('accuracy_v2',source,out)

    def test_invalid_inputs_and_bitwise_metric(self):
        with self.assertRaises(ValueError):checked_predictions(np.full((1,4),np.nan),1)
        with self.assertRaises(ValueError):checked_predictions(np.full((1,4),2),1)
        self.assertEqual(bitwise_metrics([[1,1,0,0]],[[0,0,0,0]])['ler'],.5)
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'bad.csv';p.write_text('id,basis,D0\na,X,0\n')
            with self.assertRaises(ValueError):read_test_csv(p)

if __name__=='__main__':unittest.main(verbosity=2)
